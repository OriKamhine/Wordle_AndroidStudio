package com.example.wordle;

public class Word
{
    enum letterStatus
    {
        INCORRECT, DISPLACED, CORRECT
    }

    private String secretWord;
    public Word (String secretWord)
    {
        this.secretWord = secretWord;
    }

    public letterStatus checkLetterStatus (String letter, int index)
    {
        int realId = this.secretWord.indexOf(letter);

        if(realId < 0)
        {
            return letterStatus.INCORRECT;
        }

        else if (realId != index)
        {
            return  letterStatus.DISPLACED;
        }

        else
            return letterStatus.CORRECT;
    }

    public letterStatus [] checkWord (String secretWord)
    {
        letterStatus [] letterStatuses = new letterStatus [this.secretWord.length()];

        for (int i = 0; i < letterStatuses.length; i++)
            letterStatuses[i] = this.checkLetterStatus(Character.toString(secretWord.charAt(i)), i);
        return letterStatuses;
    }
}
