package com.example.wordle;

import static com.example.wordle.Word.letterStatus.CORRECT;
import static com.example.wordle.Word.letterStatus.DISPLACED;
import static com.example.wordle.Word.letterStatus.INCORRECT;

import androidx.appcompat.app.AppCompatActivity;

import android.app.GameManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.FileNotFoundException;
import java.util.Arrays;

public class WordleActivity extends AppCompatActivity implements View.OnClickListener {


    Button btnEnter;

    Button btnDelete;

    Button btnRestart;

    Button[] abc = new Button[26];

    Button [][] wordle = new Button[6][5];

    GameManager1 gm;

    int row = 0;

    int col = 0;


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wordle);

        btnEnter = findViewById(R.id.btnEnter);
        btnDelete = findViewById(R.id.btnDelete);
        btnRestart = findViewById(R.id.btnRestart);

        btnEnter.setOnClickListener(this);
        btnDelete.setOnClickListener(this);
        btnRestart.setOnClickListener(this);
        gm = new GameManager1(this);

        Log.i("MEIR", "MAU");
        System.out.println("mauuu");

        for (int i = 0; i < abc.length; i++)
        {
            char c = (char)('A' + i);
            String str = "button" + c;
            int resID = getResources().getIdentifier(str, "id", getPackageName());
            abc[i] = findViewById(resID);
            abc[i].setOnClickListener(this);
        }
        int k = 1;
        for (int i = 0; i < 6; i++)
        {
            for (int j = 0; j < 5; j++, k++)
            {
                String str = "btn" + k;
                int resID = getResources().getIdentifier(str, "id", getPackageName());
                wordle[i][j] = findViewById(resID);
            }
        }
        System.out.println(Arrays.deepToString(wordle));
    }


    public void onClick(View view)
    {
        if (view.getId() == R.id.btnRestart)
            restart();

        else if (view.getId() == R.id.btnEnter)
        {
            String guess = "";
            for (int i = 0; i < wordle[gm.getAttempts()].length; i++)
                guess += wordle[gm.getAttempts()][i].getText().toString();

            if (guess.length() == wordle[gm.getAttempts()].length && gm.checkWord(guess))
            {
                row = gm.getAttempts();
                col = 0;
            }
        }

        else if (view.getId() == R.id.btnDelete)
        {
            if (col > 0)
            {
                wordle[row][col - 1].setText("");
                col--;
            }
        }

        else
        {
            if (col < 5)
            {
                System.out.println(row);
                System.out.println(col);
                System.out.println(gm.getAttempts());
                System.out.println("N");
                wordle[row][col].setText(((Button)view).getText().toString());
                col++;
            }
        }
    }

    public void updateLetters(Word.letterStatus[] guessed)
    {
        String guess = "";
        for (int i = 0; i < wordle[gm.getAttempts()].length; i++)
            guess += wordle[gm.getAttempts()][i].getText().toString();

        for (int i = 0; i < guessed.length; i++)
        {
            if (guessed[i] == CORRECT)
            {
                wordle[gm.getAttempts()][i].setBackgroundColor(getResources().getColor(R.color.green));
                abc[guess.charAt(i) - 'A'].setBackgroundColor(getResources().getColor(R.color.green));
            }

            else if (guessed[i] == DISPLACED)
            {
                wordle[gm.getAttempts()][i].setBackgroundColor(getResources().getColor(R.color.yellow));
                abc[guess.charAt(i) - 'A'].setBackgroundColor(getResources().getColor(R.color.yellow));
            }

            else if (guessed[i] == INCORRECT)
            {
                wordle[gm.getAttempts()][i].setBackgroundColor(getResources().getColor(R.color.light_grey));
                abc[guess.charAt(i) - 'A'].setBackgroundColor(getResources().getColor(R.color.light_grey));
            }
        }
    }


    public void clear()
    {
        for (int i = 0; i < abc.length; i ++)
            abc[i].setBackgroundColor(getResources().getColor(R.color.white));

        for (int i = 0; i < wordle.length; i++)
        {
            for (int j = 0; j < wordle[i].length; j++)
            {
                wordle[i][j].setBackgroundColor(getResources().getColor(R.color.white));
                wordle[i][j].setText("");
            }
        }
        enableKeyboard();
        row = 0;
        col = 0;
    }


    public void restart()
    {
        gm.restart();
    }

    public void toastMessage()
    {
        if(gm.getGameStatus() == 'v')
            Toast.makeText(getApplicationContext(), "Well done soldier", Toast.LENGTH_SHORT).show();

        else if (gm.getGameStatus() == 'l')
            Toast.makeText(getApplicationContext(), "What a looser", Toast.LENGTH_SHORT).show();

        else
            Toast.makeText(getApplicationContext(), "What are you doing?!", Toast.LENGTH_SHORT).show();
    }

    public void disableKeyboard()
    {
        for (int i = 0; i < abc.length; i++)
            abc[i].setClickable(false);

    }

    public void enableKeyboard()
    {
        for (int i = 0; i < abc.length; i++)
            abc[i].setClickable(true);
    }
}