package com.example.wordle;

public class GameManager1
{
    private Dictionary dictionary;

    private WordleActivity wordleUi;

    private Word current;

    private int attempts;

    private char status;


    public GameManager1(WordleActivity wordleUi)
    {
        this.wordleUi = wordleUi;

        this.dictionary = new Dictionary(this.wordleUi.getAssets());

        this.current = new Word(dictionary.getRandomWord());

        this.attempts = 0;

        this.status = 'p';
    }


    public void restart()
    {
        attempts = 0;

        status = 'p';

        this.current = new Word(dictionary.getRandomWord());

        wordleUi.clear();

    }


    public int getAttempts()
    {
        return attempts;
    }


    public boolean checkWord(String guess)
    {
        if (dictionary.In(guess))
        {
            Word.letterStatus[] arr;

            arr = current.checkWord(guess);

            this.wordleUi.updateLetters(arr);

            boolean correct = true;

            for (int i = 0; i < arr.length; i++)
            {
                if (arr[i] != Word.letterStatus.CORRECT)
                    correct = false;
            }
            this.attempts++;

            if (this.attempts >= 6)
                wordleUi.disableKeyboard();

            if(correct)
            {
                wordleUi.disableKeyboard();
                this.status = 'v';
                wordleUi.toastMessage();
            }

            else if (this.attempts >= 6)
            {
                this.status = 'l';
                wordleUi.toastMessage();
            }
            return true;
        }

        else
        {
            wordleUi.toastMessage();
            return false;
        }
    }


    public char getGameStatus()
    {
        return this.status;
    }


    public Word getCurrent()
    {
        return current;
    }
}
