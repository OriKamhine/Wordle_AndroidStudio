package com.example.wordle;

import android.content.res.AssetManager;


import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Scanner;

public class Dictionary
{

    private ArrayList<String> wordList;
    private ListIterator<String> current;

    public boolean In (String guess)
    {
        return wordList.contains(guess);
    }

    public Dictionary(AssetManager assetManager) //they helped me with this constructor that has work with files, but i managed to understand the things i need to code to work with files. in other words i know what is written in this constructor.
    {
        this.wordList = new ArrayList<String>();
        try
        {
            Scanner scanner = new Scanner(assetManager.open("DATABASE"));
            while (scanner.hasNextLine())
                wordList.add(scanner.nextLine().toUpperCase());
        }

        catch (IOException e)
        {
            throw new RuntimeException("NOT FOUND DATABASE VERY BAD ORI VERY BAD YOU GET A ZERO!!!!!");
        }

        Collections.shuffle(wordList);
        current = wordList.listIterator();
    }



    public String getRandomWord()
    {
        if (current.hasNext()) {}
        else
        {
            Collections.shuffle(wordList);
            current = wordList.listIterator();
        }
        return current.next().toUpperCase(Locale.ROOT);
    }
}
